package GUI;

import BD.a_productos;
import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.Border;

public class PLATAFORMA_US extends JFrame implements ActionListener {

    JLabel titulo;
    JPanel title_pan, back, menu, pos, bus;
    Font letra_titulo = new Font("Lucida Sans", Font.BOLD, 50);
    Font letra_boton = new Font("Lucida Sans", Font.PLAIN, 27);
    JLabel txt_busqueda;
    JTextField busqueda;
    JButton buscar;
    String[] tit_button = {"TODOS", "LIMPIEZA", "HOGAR", "SALUD", "MASCOTAS", "CARRITO"};
    Color btn_dentro = new Color(231, 199, 130);
    Color btn_fuera = new Color(102, 164, 26);
    JPanel catalogo, todos, limpieza, hogar, salud, mascotas, carrito, busq, carrito_comp;
    CardLayout cardLayout = new CardLayout();
    CardLayout cardLayout2 = new CardLayout();
    CardLayout cardLayout3 = new CardLayout();
    CardLayout cardLayout4 = new CardLayout();
    CardLayout cardLayout5 = new CardLayout();
    CardLayout cardLayout6 = new CardLayout();
    CardLayout cardLayout7 = new CardLayout();
    CardLayout cardLayout8 = new CardLayout();

    PLATAFORMA_US obj = this;

    ArrayList<Integer> carrito_barras = new ArrayList<>();
    ArrayList<Integer> carrito_cant = new ArrayList<>();
    HashMap<Integer, Integer> cod_can = new HashMap<>();

    GridBagConstraints gbc7 = new GridBagConstraints();
    GridBagConstraints gbc5 = new GridBagConstraints();
    Font letra = new Font("Lucida Sans", Font.PLAIN, 27);

    ArrayList<String> nombres_g = new ArrayList<>();
    ArrayList<String> descripciones_g = new ArrayList<>();
    ArrayList<Integer> cantidades_g = new ArrayList<>();
    ArrayList<Integer> codigos_g = new ArrayList<>();
    ArrayList<String> etiquetas_g = new ArrayList<>();
    ArrayList<Image> imageBytes_g = new ArrayList<>();
    ArrayList<Image> foto_g = new ArrayList<>();
    ArrayList<Integer> disponible_g = new ArrayList<>();
    ArrayList<Integer> vendidos_g = new ArrayList<>();
    ArrayList<Integer> precio_g = new ArrayList<>();
    JLabel total;
    JButton pag;

    public PLATAFORMA_US() {
        setTitle("MENU_USUARIO");
        setIconImage(new ImageIcon(getClass().getResource("/IMAGENES/carro.png")).getImage());
//        getContentPane().setBackground(new Color(0xF1FFEC));
// Hacer el JFrame transparente
        setUndecorated(false); // Eliminar la decoración del JFrame
        setBackground(Color.RED);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize((int) screenSize.getWidth(), (int) screenSize.getHeight());
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
//    getContentPane().setBackground(new Color(255,255,255));
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            System.out.println(ex);
        }

        UIManager.put("defaultFont", new Font("Lucida Sans", Font.PLAIN, 14));

        comp();

    }

    public void comp() {
        //PANEL QUE CONTIENE EL PANEL DE GRID
        pos = new JPanel(new BorderLayout());
        pos.setBounds(0, 0, this.getWidth(), this.getHeight());
        pos.setBackground(new Color(0xF1FFEC));
        //PANEL PRINCIPAL QUE CONTIENE LOS DEMAS PANELES
        back = new JPanel(new GridBagLayout());
        back.setBounds(0, 0, this.getWidth(), this.getHeight());
        back.setBackground(new Color(0xF1FFEC));

        GridBagConstraints gbc = new GridBagConstraints();
        //PANEL QUE CONTIENE EL TITULO
        title_pan = new JPanel();
        title_pan.setBackground(new Color(0xF1FFEC));
        title_pan.setBounds(0, 0, this.getWidth(), 270);
//        titulo = new JLabel("BIENVENIDO A SUPER EXPRESS");
//        titulo.setFont(letra_titulo);
//        titulo.setSize(1000, 40);
        ImageIcon imagenTitulo;

//        IMAGEN PANTALLA PRINCIPAL
        imagenTitulo = new ImageIcon(getClass().getResource("/IMAGENES/bienvenida.png"));
        //  si la imagen se cargó correctamente
//        if (imagenTitulo.getImageLoadStatus() == MediaTracker.COMPLETE) {
//            System.out.println("La imagen se cargó correctamente.");
//        } else {
//            System.out.println("Error al cargar la imagen.");
//        }
        titulo = new JLabel(imagenTitulo);
        titulo.setPreferredSize(new Dimension(800, 270));
        title_pan.add(titulo);
        gbc.gridx = 0;
        gbc.gridy = 0;
        back.add(title_pan, gbc);
        //PANEL  EL MENU
        menu = new JPanel(new FlowLayout());
        menu.setBackground(new Color(0xF1FFEC));

        menu.setSize(this.getWidth(), 100);
        for (int i = 0; i < tit_button.length; i++) {
            JButton ele = new JButton(tit_button[i]);
            ele.setBackground(btn_fuera);
            ele.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    ele.setBackground(btn_dentro);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    ele.setBackground(btn_fuera);
                }
            });
            ele.addActionListener(this);

            ele.setForeground(new Color(0xF1FFEC));
            ele.setFont(letra_boton);

            menu.add(ele);
        }
        gbc.gridy = 1;
        back.add(menu, gbc);
        gbc.gridy = 2;

        bus = new JPanel(new FlowLayout());
        bus.setBackground(new Color(0xF1FFEC));
        bus.setSize(this.getWidth(), 100);

        busqueda = new JTextField() {
            private final int iconPadding = 30; // Espacio para el ícono de la lupa

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon iconoLupa = new ImageIcon(getClass().getResource("/IMAGENES/lupa.png"));
                int altoIcono = iconoLupa.getIconHeight();
                int altoTexto = getHeight();
                iconoLupa.paintIcon(this, g, 5, (altoTexto - altoIcono) / 2);
            }

            @Override
            protected void paintBorder(Graphics g) {
                super.paintBorder(g);
            }

            @Override
            public void setBorder(Border border) {
                super.setBorder(border);
                // Ajustar los márgenes para dejar espacio para el ícono de lupa
                setMargin(new Insets(0, iconPadding, 0, 0));
            }
        };

        busqueda.setPreferredSize(new Dimension(500, 40)); // Tamaño del campo de búsqueda
        bus.add(busqueda);
//        txt_busqueda = new JLabel("BUSCAR:");
//        bus.add(txt_busqueda, gbc);

//        busqueda = new JTextField();
//        busqueda.setPreferredSize(new Dimension(500, 40));
//        bus.add(busqueda, gbc);
//        Botón buscar
        buscar = new JButton("BUSCAR");
        buscar.setPreferredSize(new Dimension(100, 40));
        buscar.addActionListener(this);
        buscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                buscar.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo a opaco cuando el cursor está sobre el botón
                buscar.setForeground(new Color(189, 129, 0)); // Cambiar color de texto a celeste cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                buscar.setBackground(new Color(189, 129, 0)); // Restaurar color de fondo a rojo claro
                buscar.setForeground(new Color(255, 255, 255)); // Restaurar color de texto a blanco
            }
        });

        buscar.setBackground(new Color(189, 129, 0)); // Color de fondo rojo claro
        buscar.setForeground(new Color(255, 255, 255)); // Color de texto blanco
        bus.add(buscar, gbc);

        back.add(bus, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        catalogo = new JPanel();
        catalogo.setBackground(new Color(0xF1FFEC));
        catalogo.setLayout(cardLayout);
        todos = new JPanel();
        todos.setBackground(new Color(0xF1FFEC));
        todos.setLayout(cardLayout2);
        limpieza = new JPanel();
        limpieza.setBackground(new Color(0xF1FFEC));
        limpieza.setLayout(cardLayout3);
        hogar = new JPanel();
        hogar.setLayout(cardLayout4);
        salud = new JPanel();
        salud.setBackground(new Color(0xF1FFEC));
        salud.setLayout(cardLayout5);
        mascotas = new JPanel();
        mascotas.setLayout(cardLayout6);
        mascotas.setBackground(new Color(0xF1FFEC));
        carrito = new JPanel();
        carrito.setLayout(cardLayout7);

        busq = new JPanel();
        busq.setBackground(new Color(0xF1FFEC));

        busq.setLayout(cardLayout8);

        carrito_comp = new JPanel(new GridBagLayout());
        carrito_comp.setBackground(new Color(0xF1FFEC));
        gbc5.gridx = 0;
        gbc5.gridy = 0;
        carrito_comp.add(carrito, gbc5);

        gbc5.gridy = 1;
        total = new JLabel("TOTAL: $ " + sum());
        total.setOpaque(true);
        total.setBackground(new Color(0xF1FFEC));
        total.setFont(new Font("Lucida Sans", Font.BOLD, 20));
        total.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xCCCCCC), 2),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        gbc5.gridx = 0;
        gbc5.gridy = 0;
        gbc5.insets = new Insets(0, 0, 0, 10); // Espacio a la derecha del total
        carrito_comp.add(total, gbc5);

        gbc5.gridx = 1;
        carrito_comp.add(Box.createHorizontalStrut(20), gbc5); // Espacio entre el total y el botón

        carrito_comp.add(total, gbc5);
        gbc5.gridx = 2;
        pag = new JButton("PAGAR");
        pag.setFont(new Font("Lucida Sans", Font.BOLD, 20));
        pag.setPreferredSize(new Dimension(150, 50));
        pag.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                pag.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                pag.setForeground(new Color(32, 47, 60)); // Cambiar color de texto a azul oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                pag.setBackground(new Color(247, 165, 0)); //  restaurar color naranja
                pag.setForeground(Color.WHITE); // restaurar color de texto a blanco
            }
        });
        pag.setBackground(new Color(247, 165, 0)); // Color de fondo naranja
        pag.setForeground(Color.WHITE); // Color del texto blanco
        carrito_comp.add(pag, gbc5);
        pag.addActionListener((ActionEvent e) -> {
            if (!nombres_g.isEmpty()) {

                String nombre_us = JOptionPane.showInputDialog("COLOQUE SU NOMBRE: ");
                String correo = JOptionPane.showInputDialog("COLOQUE SU CORREO:");

                String lista = "";

                if (nombre_us.matches("[a-zA-Z]+") && correo.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3,}")) {
                    a_productos n_venta = new a_productos();
                    int v_limp = 0;
                    int v_ho = 0;
                    int v_sa = 0;
                    int v_masc = 0;
                    for (int i = 0; i < nombres_g.size(); i++) {
                        String nombre = nombres_g.get(i);
                        int cantidad = cantidades_g.get(i);
                        double precio = precio_g.get(i);
                        switch (etiquetas_g.get(i)) {
                            case "LIMPIEZA":
                                v_limp += cantidades_g.get(i) * precio_g.get(i);
                                break;
                            case "HOGAR":
                                v_ho += cantidades_g.get(i) * precio_g.get(i);
                                break;
                            case "SALUD":
                                v_sa += cantidades_g.get(i) * precio_g.get(i);
                                break;
                            case "MASCOTAS":
                                v_masc += cantidades_g.get(i) * precio_g.get(i);
                                break;
                        }
                        n_venta.sumar_vend(codigos_g.get(i), cantidades_g.get(i));
                        n_venta.quitar_p(cantidades_g.get(i), codigos_g.get(i));
                        lista += String.format("%-20s x%-10d $%.2f%n", nombre, cantidad, precio);

                    }
                    try {

                        n_venta.agregarPedido(nombre_us, correo, sum(), lista);
                        n_venta.sumar_eti("LIMPIEZA", v_limp);
                        n_venta.sumar_eti("HOGAR", v_ho);
                        n_venta.sumar_eti("SALUD", v_sa);
                        n_venta.sumar_eti("MASCOTAS", v_masc);
                        n_venta.sumar_total(sum());

                        nombres_g.clear();
                        cantidades_g.clear();
                        codigos_g.clear();
                        foto_g.clear();
                        etiquetas_g.clear();
                        precio_g.clear();
                        cod_can.clear();
                        carrito.removeAll();
                        rellenarCarrito();
                        cardLayout.show(catalogo, "Carrito");
                        total.setText("TOTAL: $" + sum());

                    } catch (Exception r) {

                    }
                } else {
                    if (!nombre_us.matches("[a-zA-Z]+")) {
                        JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido (solo letras).", "Error", JOptionPane.ERROR_MESSAGE);

                    }
                    // Validar correo electrónico con expresión regular
                    if (!correo.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{3,}")) {
                        JOptionPane.showMessageDialog(this, "Por favor, ingresa un correo electrónico válido.", "Error", JOptionPane.ERROR_MESSAGE);

                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "AÑADA PRODUCTOS AL CARRITO");
            }
        });
        carrito_comp.add(pag, gbc5);

        catalogo.add(todos, "Todos");
        catalogo.add(limpieza, "Limpieza");
        catalogo.add(hogar, "Hogar");
        catalogo.add(salud, "Salud");
        catalogo.add(mascotas, "Mascotas");
        catalogo.add(carrito_comp, "Carrito");
        catalogo.add(busq, "Busqueda");

        back.add(catalogo, gbc);

        pos.add(back, BorderLayout.NORTH);
        add(pos);

    }

    public int sum() {
        int s = 0;
        System.out.println(precio_g.size());
        for (int i = 0; i < precio_g.size(); i++) {
            s += precio_g.get(i) * cantidades_g.get(i);
            System.out.println(s);
        }

        return s;
    }

    private JButton crearBotonConEstilo(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Lucida Sans", Font.BOLD, 20));
        boton.setPreferredSize(new Dimension(150, 50));
        boton.setBackground(new Color(0xd2a8ce));
        boton.setForeground(new Color(255, 255, 255));

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(0xa04d98)); // Cambiar color de texto a morado cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(0xd2a8ce)); // Restaurar color de fondo a lila
                boton.setForeground(new Color(255, 255, 255)); // Restaurar color de texto a blanco
            }
        });

        return boton;
    }

    public void rellenarLimpieza() {
        a_productos sol = new a_productos();
        sol.buscar_limpieza();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(limpieza, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(limpieza, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(limpieza, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(limpieza, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            limpieza.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) limpieza.getLayout()).first(limpieza);
    }

    public void rellenarHogar() {
        a_productos sol = new a_productos();
        sol.buscar_hogar();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(hogar, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(hogar, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(hogar, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(hogar, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            hogar.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) hogar.getLayout()).first(hogar);
    }

    public void rellenarSalud() {
        a_productos sol = new a_productos();
        sol.buscar_salud();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout5.show(salud, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout5.show(salud, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout5.show(salud, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout5.show(salud, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            hogar.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) salud.getLayout()).first(salud);
    }

    public void rellenarMascotas() {
        a_productos sol = new a_productos();
        sol.buscar_salud();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout6.show(mascotas, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout6.show(mascotas, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout6.show(mascotas, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout6.show(mascotas, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            hogar.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) mascotas.getLayout()).first(mascotas);
    }

    public void rellenarTodos() {
        a_productos sol = new a_productos();
        sol.consulta();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();
        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(todos, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(todos, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(todos, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(todos, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            todos.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) todos.getLayout()).first(todos);
    }

    private JButton estiloBoton(String texto) {
        JButton boton = new JButton(texto);
        boton.setBackground(new Color(24, 175, 90)); // Color verte metálico de fondo 
        boton.setForeground(new Color(255, 255, 255)); // Color de texto blanco
//        boton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15)); 

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(236, 236, 255)); // Color opaco fondo cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Color de texto naranja
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(new Color(24, 175, 90)); // Restaurar verde metálico
                boton.setForeground(new Color(255, 255, 255)); // Restaurar de texto blanco
            }
        });
        return boton;
    }

    public JPanel RELLENAR(String nombre, String can, String codigo, Image m, String descri, String eti, int dis, int vend, int pre) {

        GridBagConstraints gbc7 = new GridBagConstraints();
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));
        gbc7.insets = new Insets(7, 7, 7, 7);  // Adds padding around each component
        gbc7.anchor = GridBagConstraints.WEST;  // Align components to the left

        // Nombre
        gbc7.gridx = 0;
        gbc7.gridy = 0;
        JLabel nom = new JLabel("Nombre:");
        nom.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(nom, gbc7);

        gbc7.gridx = 1;
        JLabel n = new JLabel(nombre);
        n.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(n, gbc7);

        // Precio
        gbc7.gridx = 0;
        gbc7.gridy = 1;
        JLabel txtCan = new JLabel("Precio:");
        txtCan.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(txtCan, gbc7);

        gbc7.gridx = 1;
        JLabel cn = new JLabel(pre + "");
        cn.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(cn, gbc7);

        // Imagen
        if (m != null) {
            gbc7.gridx = 0;
            gbc7.gridy = 2;
            gbc7.gridwidth = 2;
            gbc7.anchor = GridBagConstraints.CENTER;
            JLabel ft = new JLabel();
            ImageIcon scaledIcon = new ImageIcon(m.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
            ft.setIcon(scaledIcon);

            panel.add(ft, gbc7);
        }

        // Botón Añadir
        gbc7.gridy = 3;
        gbc7.gridwidth = 1;
        gbc7.anchor = GridBagConstraints.WEST;
        JButton boton = estiloBoton("Añadir");
        boton.setPreferredSize(new Dimension(100, 40));
        boton.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(boton, gbc7);
        //        ACCIÓN DEL BOTÓN "AÑADIR"
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int c = Integer.parseInt(JOptionPane.showInputDialog(null, "¿CUANTOS PRODUCTOS QUIERES?"));
                    int it = 0;
                    if (cod_can.containsKey(Integer.valueOf(codigo))) {

                        for (int i = 0; i < codigos_g.size(); i++) {
//                        System.out.println("CICLO FOR DESPUES");
//                        System.out.println();
                            if (Objects.equals(codigos_g.get(i), Integer.valueOf(codigo))) {
//                            System.out.println(cantidades_g.get(i));
                                c += cantidades_g.get(i);
                                it = i;
                            }
                        }
                        if (c > Integer.parseInt(can)) {
                            JOptionPane.showMessageDialog(null, "LA CANTIDAD AÑADIDA EXCEDE EL LIMITE");
                        } else if (c < 0) {
                            JOptionPane.showMessageDialog(null, "LA CANTIDAD AÑADIDA Y EL ANTERIOR DA NUMERO NEGATIVO");
                        } else {
                            cod_can.put(Integer.valueOf(codigo), c);
                            cantidades_g.set(it, c);
                        }

                    } else {
                        System.out.println("NO HAY LLAVE");
                        System.out.println(codigo);

                        if (c > Integer.parseInt(can)) {
                            JOptionPane.showMessageDialog(null, "LA CANTIDAD EXCEDE DEL LIMITE");
                        } else if (c < 0) {
                            JOptionPane.showMessageDialog(null, "LA CANTIDAD TIENE QUE SER MÁS DE 1");
                        } else {
                            nombres_g.add(nombre);
                            cantidades_g.add(c);
                            codigos_g.add(Integer.valueOf(codigo));
                            precio_g.add(pre);
                            etiquetas_g.add(eti);
                            imageBytes_g.add(m);
                            cod_can.put(Integer.valueOf(codigo), c);
                        }
                    }
                } catch (Exception s) {
                    JOptionPane.showMessageDialog(null, "ERROR EN LOS DATOS");
                }
            }

        });

        // Botón Ver más
        gbc7.gridx = 1;
        JButton boton2 = estiloBoton("Ver más");
        boton2.setPreferredSize(new Dimension(100, 40));
        boton2.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(boton2, gbc7);
        //        ACCIÓN DEL BOTÓN "VER MÁS"
        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUI_ver_mas inicio = new GUI_ver_mas(nombre, descri, Integer.parseInt(codigo), Integer.parseInt(can), m, pre, obj, eti);
            }

        });

        return panel;
    }

    public JPanel RELLENAR_C(String nombre, String can, String codigo, Image m, String eti, int pre, int indice) {
        GridBagConstraints gbc7 = new GridBagConstraints();
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));
        gbc7.insets = new Insets(7, 7, 7, 7); 
        gbc7.anchor = GridBagConstraints.WEST; 

        int borderWidth = 2;
        Color borderColor = new Color(102, 164, 26);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, borderWidth, borderColor));
        // Nombre
        gbc7.gridx = 0;
        gbc7.gridy = 0;
        JLabel nom = new JLabel("Nombre:");
        nom.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(nom, gbc7);

        gbc7.gridx = 1;
        JLabel n = new JLabel(nombre);
        n.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(n, gbc7);

        // Precio
        gbc7.gridx = 0;
        gbc7.gridy = 1;
        JLabel txtPrecio = new JLabel("Precio:");
        txtPrecio.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(txtPrecio, gbc7);

        gbc7.gridx = 1;
        JLabel precio = new JLabel("$" + pre);
        precio.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(precio, gbc7);

        // Cantidad
        gbc7.gridx = 0;
        gbc7.gridy = 2;
        JLabel txtCantidad = new JLabel("Cantidad:");
        txtCantidad.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(txtCantidad, gbc7);

        gbc7.gridx = 1;
        JLabel cantidad = new JLabel(can);
        cantidad.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(cantidad, gbc7);

        // Imagen
        if (m != null) {
            gbc7.gridx = 0;
            gbc7.gridy = 3;
            gbc7.gridwidth = 2;  // Span across two columns
            gbc7.anchor = GridBagConstraints.CENTER;
            JLabel ft = new JLabel();

            // Aquí se integra tu código original para la imagen
            ImageIcon scaledIcon = new ImageIcon(m.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
            ft.setIcon(scaledIcon);

            panel.add(ft, gbc7);
        }

        // Botón Eliminar
        gbc7.gridy = 4;
        gbc7.gridwidth = 2;  // Reset to single column span
        gbc7.anchor = GridBagConstraints.CENTER;
        JButton canc = new JButton("Eliminar");
        canc.setPreferredSize(new Dimension(120, 40));
        canc.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(canc, gbc7);
        canc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                canc.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                canc.setForeground(new Color(174, 16, 0)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                canc.setBackground(new Color(0xf60000)); //  restaurar color de rojo metalico
                canc.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        canc.setBackground(new Color(0xf60000)); //  color de fondo a rojo metalico
        canc.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        canc.addActionListener((ActionEvent e) -> {
            nombres_g.remove(indice);
            cantidades_g.remove(indice);
            codigos_g.remove(indice);
            foto_g.remove(indice);
            etiquetas_g.remove(indice);
            precio_g.remove(indice);
            cod_can.remove(Integer.valueOf(codigo));
            carrito.removeAll();
            rellenarCarrito();
            cardLayout.show(catalogo, "Carrito");
            total.setText("TOTAL: $" + sum());
        });

        return panel;
    }

    public void rellenarCarrito() {

        int totalElementos = nombres_g.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes_g.size(); i++) {
            foto_g.add(null);
            if (imageBytes_g.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes_g.get(i));
                    foto_g.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR_C(nombres_g.get(indice), cantidades_g.get(indice).toString(), codigos_g.get(indice).toString(), foto_g.get(indice), etiquetas_g.get(indice), precio_g.get(indice), indice), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout7.show(carrito, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout7.show(carrito, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout7.show(carrito, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout7.show(carrito, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            carrito.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) carrito.getLayout()).first(carrito);
    }

    public void rellenarBusq(String nom) {
        a_productos sol = new a_productos();
        sol.consulta_busq(nom);

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();
        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(RELLENAR(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout8.show(busq, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout8.show(busq, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = crearBotonConEstilo("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout8.show(busq, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = crearBotonConEstilo("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout8.show(busq, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            busq.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) busq.getLayout()).first(busq);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton botonPresionado = (JButton) e.getSource();
        String textoBoton = botonPresionado.getLabel();

        if (e.getSource() == buscar) {
            busq.removeAll();
            if (busqueda.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "COLOQUE UN NOMBRE DE ALGUN PRODUCTO QUE BUSQUE");
            } else {
                rellenarBusq(busqueda.getText());
                cardLayout.show(catalogo, "Busqueda");
            }

        }

        switch (textoBoton) {
            case "TODOS":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 1
                System.out.println("Presionaste el botón 1");
                todos.removeAll();
                rellenarTodos();
                cardLayout.show(catalogo, "Todos");
                break;
            case "LIMPIEZA":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 2
                System.out.println("Presionaste el botón 2");
                limpieza.removeAll();
                rellenarLimpieza();
                cardLayout.show(catalogo, "Limpieza");
                break;
            case "HOGAR":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                System.out.println("Presionaste el botón 3");
                hogar.removeAll();
                rellenarHogar();
                cardLayout.show(catalogo, "Hogar");
                break;
            case "SALUD":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                System.out.println("Presionaste el botón 3");
                salud.removeAll();
                rellenarSalud();
                cardLayout.show(catalogo, "Salud");
                break;
            case "MASCOTAS":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                System.out.println("Presionaste el botón 3");
                mascotas.removeAll();
                rellenarLimpieza();
                cardLayout.show(catalogo, "Mascotas");
                break;
            case "CARRITO":
                carrito.removeAll();
                rellenarCarrito();
                cardLayout.show(catalogo, "Carrito");
                total.setText("TOTAL: $" + sum());
                System.out.println("Presionaste el botón CARRITO");
                break;

        }
    }
}
