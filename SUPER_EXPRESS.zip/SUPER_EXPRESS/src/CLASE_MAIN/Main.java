/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CLASE_MAIN;

import GUI.PLATAFORMA_US;

/**
 *
 * @author lucho
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PLATAFORMA_US inicio = new PLATAFORMA_US();
        inicio.setVisible(true);
    }
    
}
