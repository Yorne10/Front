/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import BD.a_productos;
import BD.cconexion;
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComboBoxUI;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.plot.PiePlot;
import java.awt.BasicStroke;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.border.Border;

public class PLATAFORMA_ADMIN extends JFrame implements ActionListener {

    Color btn_dentro = new Color(231, 199, 130);
    Color btn_fuera = new Color(102, 164, 26);
    CardLayout cardLayout = new CardLayout();
    CardLayout cardLayout2 = new CardLayout();
    CardLayout cardLayout4 = new CardLayout();
    CardLayout cardLayout3 = new CardLayout();
    Font letra = new Font("Lucida Sans", Font.PLAIN, 16);
    Font letra_boton = new Font("Lucida Sans", Font.PLAIN, 27);
    JPanel pos, btns, cont, contenido, ped, est, agre, eli, soli, modi;
    String[] btns_nombre = {"Pedidos", "Estadisticas", "Agregar", "Eliminar", "Solicitar", "Modificar"};
    GridBagConstraints gbc = new GridBagConstraints();
    GridBagConstraints gbc2 = new GridBagConstraints();
    GridBagConstraints gbc3 = new GridBagConstraints();
    GridBagConstraints gbc4 = new GridBagConstraints();
    GridBagConstraints gbc5 = new GridBagConstraints();
    GridBagConstraints gbc6 = new GridBagConstraints();
    GridBagConstraints gbc7 = new GridBagConstraints();
    JTextField nom, des, can, cod, pre;
    JTextField e_cod;
    PLATAFORMA_ADMIN apuntador = this;

    public File selectFile;

    public PLATAFORMA_ADMIN() {
        setTitle("MENU_ADMINISTRADOR");
        setIconImage(new ImageIcon(getClass().getResource("/IMAGENES/usuario.png")).getImage());
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize((int) screenSize.getWidth(), (int) screenSize.getHeight() - 100);
        setLocationRelativeTo(null);
        setLayout(null);
//        cconexion objetocon = new cconexion();
//        objetocon.estableceConexion();
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
//        getContentPane().setBackground(new Color(255,255,255));

        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            System.out.println(ex);
        }

        UIManager.put("defaultFont", new Font("Lucida Sans", Font.PLAIN, 14));
        comp();
    }

    public void comp() {

        pos = new JPanel(new BorderLayout());
        pos.setBounds(0, 0, this.getWidth(), this.getHeight());
        pos.setBackground(new Color(0xF1FFEC));

        System.out.println(this.getHeight());
        btns = new JPanel();
        btns.setBackground(new Color(0xF1FFEC));

        btns.setBounds(0, 0, 100, this.getHeight());
        System.out.println(getHeight());
        btns.setLayout(new GridLayout(btns_nombre.length, 1));
        for (int i = 0; i < btns_nombre.length; i++) {
            JButton ele = new JButton(btns_nombre[i]);
            ele.setBackground(btn_fuera);
            ele.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    ele.setBackground(btn_dentro);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    ele.setBackground(btn_fuera);
                }
            });
            ele.addActionListener(this);

            ele.setForeground(new Color(0xF1FFEC));
            ele.setFont(letra_boton);

            btns.add(ele);
        }
        pos.add(btns, BorderLayout.WEST);
        contenido = new JPanel(cardLayout);
        contenido.setBackground(new Color(0xF1FFEC));
        contenido.setBackground(btn_fuera);
        ped = new JPanel(cardLayout4);
        ped.setBackground(new Color(0xF1FFEC));

        agre = new JPanel();
        agre.setBackground(new Color(0xF1FFEC));
        agre.add(ag());
        est = new JPanel();
        est.setBackground(new Color(0xF1FFEC));
        est.add(est("SOPA", "255", "ARROZ", "455555", 10, 50, 70, 40));

        eli = new JPanel();
        eli.setBackground(new Color(0xF1FFEC));
        eli.add(eliminar());

        soli = new JPanel(cardLayout2);
        soli.setBackground(new Color(0xF1FFEC));
        gbc5.gridx = 0;
        gbc5.gridy = 0;
        JLabel tit = new JLabel("SOLICITAR PEDIDOS");
        tit.setFont(letra);
//        soli.add(tit, gbc5);
//        for (int i = 0; i < 3; i++) {
//            gbc5.gridy = i + 1;
//            for (int e = 0; e < 6; e++) {
//                gbc5.gridx = e + 1;
//                gbc5.insets = new Insets(10, 10, 10, 10);  // Puedes ajustar los valores a tu gusto
//                soli.add(solicitar("JABON", "5", "233223"), gbc5);
//            }
//        }

        modi = new JPanel(cardLayout3);
        modi.setBackground(new Color(0xF1FFEC));
        gbc6.gridx = 0;
        gbc6.gridy = 0;
//        JLabel t = new JLabel("MODIFICAR PRODUCTOS");
//        t.setFont(letra);
//        modi.add(t, gbc6);
//        for (int i = 0; i < 3; i++) {
//            gbc6.gridy = i + 1;
//            for (int e = 0; e < 6; e++) {
//                gbc6.gridx = e + 1;
//                gbc6.insets = new Insets(10, 10, 10, 10);  // Puedes ajustar los valores a tu gusto
//                modi.add(Modificar("JABON", "5", "233223"), gbc6);
//            }
//        }

        contenido.add(ped, "Pedido");
        contenido.add(est, "Estadisticas");
        contenido.add(agre, "Agregar");
        contenido.add(eli, "Eliminar");
        contenido.add(soli, "Solicitar");
        contenido.add(modi, "Modificar");

        pos.add(contenido, BorderLayout.CENTER);
        add(pos);
    }

    public JPanel pedidos(String nombre, String lista, String correo, int total, int indice, int ID) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));

        gbc7.gridx = 0;
        gbc7.gridy = 0;

        JLabel nom = new JLabel("Nombre:");

        panel.add(nom, gbc7);
        gbc7.gridy = 1;
        JLabel n = new JLabel(nombre);
        panel.add(n, gbc7);
        gbc7.gridy = 2;
        JLabel lbl_lista = new JLabel("Lista");
        panel.add(lbl_lista, gbc7);
        gbc7.gridy = 3;
        JTextArea li_tot = new JTextArea(lista);
        JScrollPane scroll = new JScrollPane(li_tot);
        li_tot.setEditable(false);
        scroll.setPreferredSize(new Dimension(100, 100));
        panel.add(scroll, gbc7);
        gbc7.gridy = 4;
        JLabel tot = new JLabel("Total :");
        panel.add(tot, gbc7);
        gbc7.gridy = 5;
        JLabel lbl_tot = new JLabel(total + "");
        lbl_tot.setOpaque(false); // JTextArea sea transparente
        lbl_tot.setBackground(new Color(0, 0, 0, 0)); //  de fondo transparente
        panel.add(lbl_tot, gbc7);
        gbc7.gridy = 6;
//        BOTÓN CONFIRMAR PEDIDO
        JButton boton = new JButton("Confirmar");
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo a opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(189, 129, 0)); // Cambiar color de texto a celeste cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(189, 129, 0)); // Restaurar color de fondo a rojo claro
                boton.setForeground(new Color(255, 255, 255)); // Restaurar color de texto a blanco
            }
        });
        boton.setBackground(new Color(189, 129, 0)); //  color de fondo a verde metalico
        boton.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
//       ACCIÓN DE BOTÓN CONFIRMAR EL PEDIDO
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                a_productos terminar = new a_productos();
                terminar.terminar_pedido(ID);
                ped.removeAll();
                rellenarprodu();
            }
        });
        gbc7.gridy = 7;
        panel.add(boton, gbc7);

        return panel;
    }

    public void rellenarprodu() {
        a_productos sol = new a_productos();
        sol.consulta_pedidos();

        ArrayList<String> usuario = sol.getUsuario();
        ArrayList<String> correo = sol.getCorreo();
        ArrayList<String> pedido = sol.getPedido();
        ArrayList<Integer> total = sol.getTotal();
        ArrayList<Integer> ID = sol.getID();

        int totalElementos = usuario.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));
            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(pedidos(usuario.get(indice), pedido.get(indice), correo.get(indice), total.get(indice), indice, ID.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseEntered(MouseEvent e) {
                            // Cambiar estilo cuando el cursor está sobre el botón
                            next.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                            next.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            // Cambiar estilo cuando el cursor no está sobre el botón
                            next.setBackground(new Color(24, 175, 90)); //  restaurar color de verde metalico
                            next.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
                        }
                    });
                    next.setBackground(new Color(24, 175, 90)); //  color de fondo a verde metalico
                    next.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
                    next.addActionListener(new ActionListener() { //acción de botón next
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(ped, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(ped, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(ped, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout4.show(ped, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            ped.add(panelPagina, "Pagina " + (pagina));
        }

        ((CardLayout) ped.getLayout()).first(ped);
    }

    public JPanel Modificar(String nombre, String can, String codigo, Image m, String descri, String eti, int dis, int vend, int pre) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));
//           panel.setPreferredSize(new Dimension(400, 600)); 

        gbc7.gridx = 0;
        gbc7.gridy = 0;
        JLabel nom = new JLabel("Nombre:");

        panel.add(nom, gbc7);
        JLabel n = new JLabel(nombre);
        gbc7.gridy = 1;
        panel.add(n, gbc7);
        JLabel txtCan = new JLabel("Cantidad:");
        gbc7.gridy = 2;
        panel.add(txtCan, gbc7);
        JLabel cn = new JLabel(can);
        gbc7.gridy = 3;
        panel.add(cn, gbc7);

        JLabel txt_cod = new JLabel("Cod. de barras:");
        gbc7.gridy = 4;
        panel.add(txt_cod, gbc7);
        JLabel cod = new JLabel(codigo);
        gbc7.gridy = 5;
        panel.add(cod, gbc7);

        gbc7.gridy = 6;
        JLabel ft = new JLabel();
        ft.setPreferredSize(new Dimension(75, 75));
        panel.add(ft, gbc7);

        ImageIcon originalIcon = new ImageIcon(m);

        int lblwidth = ft.getWidth();
        int lblheight = ft.getHeight();

        Image scalImage = originalIcon.getImage().getScaledInstance(75, 75, Image.SCALE_SMOOTH);
        ft.setIcon(new ImageIcon(scalImage));

        JButton boton = new JButton("MODIFICAR");
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(255, 165, 0)); //  restaurar color de verde metalico
                boton.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        boton.setBackground(new Color(247, 165, 0)); //  color de fondo a verde metalico
        boton.setForeground(new Color(255, 255, 255)); //  color de texto a blanco

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                GUI_MODI ventana = new GUI_MODI(nombre, can, codigo, m, descri, eti, dis, vend, apuntador, pre);

            }

        });
        gbc7.gridy = 7;
        panel.add(boton, gbc7);

        return panel;
    }

    public JPanel solicitar(String nombre, String can, String codigo, Image m) {
//      
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));

        gbc7.gridx = 0;
        gbc7.gridy = 0;
        int cnt = Integer.parseInt(can);
        if (cnt > 50) {
            panel.setBackground(new Color(0xF1FFEC));
        } else if (cnt < 50) {
            panel.setBackground(new Color(0xF1FFEC));
            if (cnt < 20) {
                panel.setBackground(new Color(0xF1FFEC));
            }
        }

        JLabel nom = new JLabel("Nombre :");

        panel.add(nom, gbc7);
        gbc7.gridy = 1;
        JLabel n = new JLabel(nombre);

        panel.add(n, gbc7);
        JLabel txtCan = new JLabel("Cantidad :");
        gbc7.gridy = 2;
        panel.add(txtCan, gbc7);
        JLabel cn = new JLabel(can);
        gbc7.gridy = 3;
        panel.add(cn, gbc7);

        JLabel txt_cod = new JLabel("Cod. de barras :");
        gbc7.gridy = 4;
        panel.add(txt_cod, gbc7);
        JLabel cod = new JLabel(codigo);
        gbc7.gridy = 5;
        panel.add(cod, gbc7);

        gbc7.gridy = 6;
        JLabel ft = new JLabel();
        ft.setPreferredSize(new Dimension(75, 75));
        panel.add(ft, gbc7);

        ImageIcon originalIcon = new ImageIcon(m);

        int lblwidth = ft.getWidth();
        int lblheight = ft.getHeight();

        Image scalImage = originalIcon.getImage().getScaledInstance(75, 75, Image.SCALE_SMOOTH);
        ft.setIcon(new ImageIcon(scalImage));

        JButton boton = new JButton("PEDIR");
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(255, 165, 0)); //  restaurar color de verde metalico
                boton.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        boton.setBackground(new Color(247, 165, 0)); //  color de fondo a verde metalico
        boton.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                accion_pedir(codigo);
            }
        });
        gbc7.gridy = 7;
        panel.add(boton, gbc7);

        return panel;
    }

    public void accion_pedir(String codigo) {
        try {
            int c = Integer.parseInt(codigo);
            int mas = Integer.parseInt(JOptionPane.showInputDialog(null, "¿Cuantos elementos quieres pedir?"));

            a_productos pd = new a_productos();
            pd.sumar(c, mas);
            actualizarSoli();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA CANTIDAD");
        }
    }

    public JPanel eliminar() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));
        GridBagConstraints gbc4 = new GridBagConstraints();
        gbc4.insets = new Insets(7, 7, 7, 7); // Añadir relleno alrededor de cada componente

        // Imagen en el medio en la parte superior
        gbc4.gridx = 0;
        gbc4.gridy = 0;
        gbc4.gridwidth = 2; // Span across two columns
        gbc4.anchor = GridBagConstraints.CENTER; // Centramos la imagen
        JLabel newImageLabel = new JLabel(new ImageIcon(getClass().getResource("/IMAGENES/eliminarTit.png")));
        panel.add(newImageLabel, gbc4);

        gbc4.gridwidth = 1;
        gbc4.anchor = GridBagConstraints.EAST; // Alinear el texto a la derecha
        gbc4.gridy = 1;
        gbc4.gridx = 0;
        JLabel txt_n = new JLabel("Código de barras:");
        txt_n.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(txt_n, gbc4);

        gbc4.gridx = 1;
        gbc4.anchor = GridBagConstraints.WEST;
        e_cod = new JTextField();
        e_cod.setPreferredSize(new Dimension(200, 30)); // Reducir el tamaño del campo de texto
        e_cod.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(e_cod, gbc4);

        // Botón Eliminar
        gbc4.gridy = 2;
        gbc4.gridx = 0;
        gbc4.gridwidth = 2; // Ocupar dos columnas para el botón
        gbc4.anchor = GridBagConstraints.CENTER; // Centrar el botón horizontalmente
        JButton boton = new JButton("Eliminar");
        boton.setPreferredSize(new Dimension(120, 40));
        boton.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        panel.add(boton, gbc4);

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(255, 165, 0)); // Restaurar color de fondo a naranja metálico
                boton.setForeground(new Color(255, 255, 255)); // Restaurar color de texto a blanco
            }
        });
        boton.setBackground(new Color(247, 165, 0)); // Color de fondo a naranja metálico
        boton.setForeground(new Color(255, 255, 255)); // Color de texto a blanco

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int c = Integer.parseInt(e_cod.getText());
                    boolean val_codigo = String.valueOf(Math.abs(c)).length() == 9;
                    if (val_codigo) {
                        a_productos borrar = new a_productos();
                        borrar.eliminar(c);
                    } else {
                        JOptionPane.showMessageDialog(null, "EL CÓDIGO ES DE 9 DIGITOS");
                    }
                } catch (Exception s) {
                    JOptionPane.showMessageDialog(null, "ERROR EN EL CODIGO DE BARRAS VUELVE A COLOCAR EL CODIGO");
                }
            }
        });

        return panel;
    }

    public JPanel est(String p_m_v, String ganancias, String p_menos_v, String inv_tot, int limp, int hogar, int salud, int mascotas) {
        est.setBackground(new Color(0xF1FFEC));
        JPanel estadisticas = new JPanel(new GridBagLayout());
        estadisticas.setBackground(new Color(0xF1FFEC));
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.insets = new Insets(7, 0, 0, 0);

        JLabel imagenLabel = new JLabel(new ImageIcon(getClass().getResource("/IMAGENES/estadisticasTit.png")));
        gbc2.gridx = 0;
        gbc2.gridy = 0;
        gbc2.anchor = GridBagConstraints.PAGE_START;
        estadisticas.add(imagenLabel, gbc2);

        gbc2.gridy = 1;
        JLabel mas = new JLabel("Producto MÁS vendido es: " + p_m_v);
        mas.setFont(letra);
        estadisticas.add(mas, gbc2);
        gbc2.gridy = 2;
        JLabel menos = new JLabel("Producto MENOS vendido es: " + p_menos_v);
        menos.setFont(letra);
        estadisticas.add(menos, gbc2);
        JLabel gan = new JLabel("Ganancias: $" + ganancias);
        gan.setFont(letra);
        gbc2.gridy = 3;
        estadisticas.add(gan, gbc2);
        JLabel pro_t = new JLabel("Total de productos: " + inv_tot);
        pro_t.setFont(letra);
        gbc2.gridy = 4;

        estadisticas.add(pro_t, gbc2);

        gbc2.insets = new Insets(45, 0, 0, 0);
        DefaultPieDataset datos = new DefaultPieDataset();
        datos.setValue("LIMPIEZA", limp);
        datos.setValue("HOGAR", hogar);
        datos.setValue("SALUD", salud);
        datos.setValue("MASCOTAS", mascotas);

        JFreeChart graficoCircular = ChartFactory.createPieChart(
                "VENTAS POR CATEGORIA",
                datos,
                true,
                true,
                false
        );

        graficoCircular.setBackgroundPaint(new Color(241, 255, 236)); // Color de fondo
        graficoCircular.getTitle().setPaint(new Color(0, 102, 51)); // Color del título

        //  plot del gráfico 
        PiePlot plot = (PiePlot) graficoCircular.getPlot();
        plot.setBackgroundPaint(new Color(241, 255, 236)); //  fondo del gráfico
        plot.setSectionOutlineStroke(new BasicStroke(2)); // Grosor del borde del círculo
        plot.setSectionOutlinePaint(Color.WHITE); // Color del borde 
        plot.setShadowPaint(new Color(0, 0, 0, 100)); // sombra
//       plot.setSectionDepth(0.15); // Grosor rueda 

        // colores de las secciones del gráfico
        plot.setSectionPaint("LIMPIEZA", new Color(255, 203, 54)); // Naranja
        plot.setSectionPaint("HOGAR", new Color(211, 149, 255)); // lila
        plot.setSectionPaint("SALUD", new Color(161, 220, 255)); // Azul claro
        plot.setSectionPaint("MASCOTAS", new Color(255, 115, 142)); // Rosa

        // Ajustar etiquetas
        plot.setLabelBackgroundPaint(new Color(0xF1FFEC)); //  fondo 
        plot.setLabelOutlinePaint(null);
        plot.setLabelShadowPaint(null);
        plot.setLabelFont(new Font("Lucida Sans", Font.PLAIN, 12));

        ChartPanel panel = new ChartPanel(graficoCircular);
        panel.setMouseWheelEnabled(true);
//        panel.setBorder(null);
        Border borde = BorderFactory.createLineBorder(new Color(0xF1FFEC));
        panel.setBorder(borde);
        panel.setPreferredSize(new Dimension(420, 350));

        gbc2.gridx = 0;
        gbc2.gridy = 5;
        estadisticas.add(panel, gbc2);

        return estadisticas;
    }

    public JPanel info(String us, String lista, String precio) {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(0xF1FFEC));
        panel.setLayout(new GridLayout(7, 1));
        JLabel nombre = new JLabel("Nombre:");
        JLabel txt_nom = new JLabel(us);
        JLabel lis = new JLabel("LISTA: ");
        JTextArea cont = new JTextArea(lista);
        JScrollPane contenedor = new JScrollPane(cont);
        cont.setSize(200, 500);
        cont.setEditable(false);
        JLabel pre = new JLabel("Precio: $" + precio);
        JButton dar = new JButton("ENTREGAR");
        JButton can = new JButton("CANCELAR");
        panel.add(nombre);
        panel.add(txt_nom);
        panel.add(lis);
        panel.add(contenedor);
        panel.add(pre);
        panel.add(dar);
        panel.add(can);
        return panel;
    }

    public JPanel ag() {
        GridBagConstraints gbc3 = new GridBagConstraints();
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF1FFEC));
        gbc3.insets = new Insets(5, 5, 5, 5);

        gbc3.gridx = 0;
        gbc3.gridy = 0;
        gbc3.gridwidth = 2;

        gbc3.anchor = GridBagConstraints.CENTER; // Centramos la imagen
        JLabel newImageLabel = new JLabel(new ImageIcon(getClass().getResource("/IMAGENES/agTit.png")));
        panel.add(newImageLabel, gbc3);
        panel.add(Box.createGlue(), gbc3);

        gbc3.gridwidth = 1;
        gbc3.gridx = 0;
        gbc3.gridy = 1;
        gbc3.anchor = GridBagConstraints.EAST;
        JLabel txt_nm = new JLabel("Nombre:");
        txt_nm.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_nm, gbc3);

        gbc3.gridwidth = 1;
        gbc3.gridy = 2;
        JLabel txt_des = new JLabel("Descripcion corta:");
        txt_des.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_des, gbc3);

        gbc3.gridwidth = 1;
        gbc3.gridy = 3;
        JLabel txt_cant = new JLabel("Cantidad: ");
        txt_cant.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_cant, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridy = 4;
        JLabel txt_cod = new JLabel("Código de barras: ");
        txt_cod.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_cod, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridy = 5;
        JLabel txt_pre = new JLabel("Precio: ");
        txt_pre.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_pre, gbc3);

//        NOMBRE
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 1;
        nom = new JTextField();
        nom.setPreferredSize(new Dimension(200, 30));
        nom.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(nom, gbc3);
//        DESCRIPCIÓN
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 2;
        des = new JTextField();
        des.setPreferredSize(new Dimension(200, 30));
        des.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(des, gbc3);
//        CANTIDAD
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 3;
        can = new JTextField();
        can.setPreferredSize(new Dimension(200, 30));
        can.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(can, gbc3);
//        COD BARRAS
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 4;
        cod = new JTextField();
        cod.setPreferredSize(new Dimension(200, 30));
        cod.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(cod, gbc3);
//        PRECIO 
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 5;
        pre = new JTextField("");
        pre.setPreferredSize(new Dimension(200, 30));
        pre.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
        panel.add(pre, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 0;
        gbc3.gridy = 6;

        JLabel txt_et = new JLabel("Etiqueta:");
        txt_et.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txt_et, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 6;
        String[] opciones = {"Limpieza", "Hogar", "Salud", "Mascotas"};
        JComboBox<String> comboBox = new JComboBox<>(opciones);
        comboBox.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(comboBox, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 3;
//        cod = new JTextField();
//        cod.setPreferredSize(new Dimension(200, 30));
//        cod.setFont(new Font("Lucida Sans", Font.PLAIN, 14));
//        panel.add(cod, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 0;
        gbc3.gridy = 7;
        JLabel txtfoto = new JLabel("Foto:");
        txtfoto.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        panel.add(txtfoto, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 8;
        JTextField ruta = new JTextField();
        ruta.setEditable(false);
        ruta.setPreferredSize(new Dimension(200, 30));
        panel.add(ruta, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 10;
        JLabel img = new JLabel();
        img.setPreferredSize(new Dimension(100, 100));
        panel.add(img, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 0;
        gbc3.gridy = 7;
        gbc3.gridwidth = 2;
        JButton btnimg = new JButton("Explorar");
        btnimg.setFont(new Font("Lucida Sans", Font.BOLD, 14));
        btnimg.setPreferredSize(new Dimension(140, 40));
        btnimg.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                btnimg.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                btnimg.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                btnimg.setBackground(new Color(135, 206, 230)); //  restaurar color de verde metalico
                btnimg.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        btnimg.setBackground(new Color(135, 206, 230)); //  color de fondo a verde metalico
        btnimg.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        btnimg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();

                int result = fileChooser.showOpenDialog(null);

                if (result == JFileChooser.APPROVE_OPTION) {
                    selectFile = fileChooser.getSelectedFile();
                    ruta.setText(selectFile.getName());
                    try {
                        Image imag = ImageIO.read(selectFile);
                        ImageIcon originalIcon = new ImageIcon(imag);

                        int lblwidth = img.getWidth();
                        int lblheight = img.getHeight();

                        Image scalImage = originalIcon.getImage().getScaledInstance(lblwidth, lblheight, Image.SCALE_SMOOTH);
                        img.setIcon(new ImageIcon(scalImage));

                    } catch (Exception s) {
                        JOptionPane.showMessageDialog(null, "ERROR AL CARGAR");
                    }
                }
            }
        });
        panel.add(btnimg, gbc3);
        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 9;
        JLabel txtimg = new JLabel("*Imagen seleccionada*");
        txtimg.setFont(new Font("Lucida Sans", Font.PLAIN, 13));
        panel.add(txtimg, gbc3);

        gbc3.gridwidth = 1;
        gbc3.gridx = 0;
        gbc3.gridy = 11;
        gbc3.gridwidth = 2; // Abarca dos columnas
        panel.add(Box.createRigidArea(new Dimension(10, 10)), gbc3); // Espacio rígido

        gbc3.gridwidth = 1;
        gbc3.gridx = 1;
        gbc3.gridy = 12;
        gbc3.gridwidth = 1;
        JButton boton = new JButton("Aceptar");
        boton.setPreferredSize(new Dimension(120, 50));
        boton.setFont(new Font("Lucida Sans", Font.BOLD, 15));
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                boton.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                boton.setBackground(new Color(255, 165, 0)); //  restaurar color de verde metalico
                boton.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        boton.setBackground(new Color(247, 165, 0)); //  color de fondo a verde metalico
        boton.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    a_productos objeto_producto = new a_productos();
                    String nombre = nom.getText();
                    String descripcion = des.getText();
                    int cantidad = Integer.parseInt(can.getText());
                    int precio = Integer.parseInt(pre.getText());
                    int codigo = Integer.parseInt(cod.getText());

                    String etiq = comboBox.getSelectedItem().toString();
                    boolean llenado = !nombre.isEmpty() && !descripcion.isEmpty();
                    boolean val_codigo = String.valueOf(Math.abs(codigo)).length() == 9;
                    if (llenado && val_codigo && objeto_producto.val_codigo(cod.getText())) {
                        objeto_producto.agregarProducto(nombre, descripcion, cantidad, codigo, etiq, selectFile, precio);
                        nom.setText("");
                        des.setText("");
                        can.setText("");
                        cod.setText("");
                        pre.setText("");
                        ruta.setText("");
                        img.setIcon(null);

                    } else {
                        if (!objeto_producto.val_codigo(cod.getText())) {
                            JOptionPane.showMessageDialog(null, "CODIGO DE BARRAS YA UTILIZADO");
                        } else {
                            JOptionPane.showMessageDialog(null, "ERROR EN LOS DATOS, POR FAVOR TEN EN CUENTA QUE DEBES COMPLETAR TODOS LOS DATOS Y QUE EL CÓDIGO DE BARRAS DEBE TENER SOLO 9 DÍGITOS");
                            //System.out.println(String.valueOf(Math.abs(codigo)).length() + "kflok");

                        }

                    }

                } catch (Exception rs) {
                    JOptionPane.showMessageDialog(null, "ERROR EN LOS DATOS, POR FAVOR TEN EN CUENTA QUE DEBES COMPLETAR TODOS LOS DATOS Y QUE EL CÓDIGO DE BARRAS DEBE TENER SOLO 9 DÍGITOS " + rs);

                }

            }
        });
        panel.add(boton, gbc3);

        return panel;
    }

    public void rellenarSoli() {
        a_productos sol = new a_productos();
        sol.consulta();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));

            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(solicitar(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(soli, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(soli, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(soli, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout2.show(soli, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            soli.add(panelPagina, "Pagina " + (pagina));
        }

        ((CardLayout) soli.getLayout()).first(soli);
    }

    public void rellenarModi() {
        a_productos sol = new a_productos();
        sol.consulta();

        ArrayList<String> nombres = sol.getNombres();
        ArrayList<String> descripciones = sol.getDescripciones();
        ArrayList<Integer> cantidades = sol.getCantidades();
        ArrayList<Integer> codigos = sol.getCodigos();
        ArrayList<String> etiquetas = sol.getEtiquetas();
        ArrayList<byte[]> imageBytes = sol.getImageBytes();
        ArrayList<Image> foto = new ArrayList<>();
        ArrayList<Integer> disponible = sol.getDisponible();
        ArrayList<Integer> vendidos = sol.getVendidos();
        ArrayList<Integer> precio = sol.getPrecio();

        int totalElementos = nombres.size();
        int elementosPorPagina = 15;
        int totalPaginas = (int) Math.ceil((double) totalElementos / elementosPorPagina);

        for (int i = 0; i < imageBytes.size(); i++) {
            foto.add(null);
            if (imageBytes.get(i) != null) {
                try {
                    ImageIcon imageIcon = new ImageIcon(imageBytes.get(i));
                    foto.add(i, imageIcon.getImage());
                } catch (Exception d) {
                    JOptionPane.showMessageDialog(null, "ERROR: " + d.toString());
                }
            }
        }

        for (int pagina = 0; pagina < totalPaginas; pagina++) {
            final int pag = pagina;
            JPanel panelPagina = new JPanel(new GridBagLayout());
            panelPagina.setBackground(new Color(0xF1FFEC));

            GridBagConstraints gbc = new GridBagConstraints();

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    int indice = pagina * elementosPorPagina + i * 5 + j;
                    if (indice < totalElementos) {
                        gbc.gridy = i;
                        gbc.gridx = j;
                        gbc.insets = new Insets(10, 10, 10, 10);
                        panelPagina.add(Modificar(nombres.get(indice), cantidades.get(indice).toString(), codigos.get(indice).toString(), foto.get(indice), descripciones.get(indice), etiquetas.get(indice), disponible.get(indice), vendidos.get(indice), precio.get(indice)), gbc);
                    }
                }
            }
            String txtnxt = "Pagina " + (pagina + 1);
            String txtbk = "Pagina " + (pagina - 1);
//        System.out.println(txtnxt);
//        System.out.println(txtbk);
//        System.out.println(pag);
            if (totalPaginas > 1) {
                if (pagina == 0) {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(modi, txtnxt);
//                System.out.println("SIGUIENTE");
                        }
                    });
                    next.setFont(letra);
                    panelPagina.add(next, gbc);
                } else if (pagina == totalPaginas - 1) {
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(modi, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                } else {
                    gbc.gridy = 4;
                    gbc.gridx = 5;
                    JButton next = new JButton("SIGUIENTE");
                    next.setFont(letra);
                    next.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(modi, txtnxt);
                        }
                    });

                    panelPagina.add(next, gbc);
                    gbc.gridy = 4;
                    gbc.gridx = 0;
                    JButton back = new JButton("ATRAS");
                    back.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            cardLayout3.show(modi, txtbk);
                        }
                    });
                    back.setFont(letra);
                    panelPagina.add(back, gbc);
                }
            }

            modi.add(panelPagina, "Pagina " + (pagina));
        }
        ((CardLayout) modi.getLayout()).first(modi);
    }

    public void actualizarSoli() {
        cardLayout.show(contenido, "Solicitar");
        soli.removeAll();
        rellenarSoli();
    }

    public void actualizarModi() {
        cardLayout.show(contenido, "Modificar");
        modi.removeAll();
        rellenarModi();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton botonPresionado = (JButton) e.getSource();
        String textoBoton = botonPresionado.getLabel();

        switch (textoBoton) {
            case "Pedidos":
                cardLayout.show(contenido, "Pedido");
                ped.removeAll();
                rellenarprodu();
                break;
            case "Agregar":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 2
                cardLayout.show(contenido, "Agregar");
                break;
            case "Eliminar":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                cardLayout.show(contenido, "Eliminar");
                break;
            case "Solicitar":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                cardLayout.show(contenido, "Solicitar");
                soli.removeAll();
                rellenarSoli();
                break;
            case "Modificar":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                cardLayout.show(contenido, "Modificar");
                modi.removeAll();
                rellenarModi();
                break;
            case "Estadisticas":
                // Aquí va el código que quieres que se ejecute cuando se presione el botón 3
                cardLayout.show(contenido, "Estadisticas");
                break;
        }
    }
}
