/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import BD.a_productos;
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;

public class GUI_MODI extends JFrame implements ActionListener {

    String nombre, can, codigo, descri, eti;
    Image m;
    int dis, vend, precio;
    PLATAFORMA_ADMIN obj;
    boolean cambioImg;
    File selectFile;

    JLabel tit, txt_nom, txt_can, txt_codigo, txt_descri, txt_eti, txt_m, txt_dis, txt_vend, f_m, ruta, txt_pre;
    JTextField f_nom, f_can, f_codigo, f_descri, f_eti, f_dis, f_vend, f_pre;
    JButton boton_cancelar, boton_aceptar, explorar;

    public GUI_MODI(String nombre, String can, String codigo, Image m, String descri, String eti, int dis, int vend, PLATAFORMA_ADMIN obj, int precio) {
        setIconImage(new ImageIcon(getClass().getResource("/IMAGENES/modificar.png")).getImage());
        this.nombre = nombre;
        this.can = can;
        this.codigo = codigo;
        this.m = m;
        this.descri = descri;
        this.eti = eti;
        this.dis = dis;
        this.precio = precio;

        this.vend = vend;
        this.obj = obj;
        setTitle("Modificación - " + nombre);
        setResizable(false);
        setSize(400, 660);
        try {
            UIManager.setLookAndFeel(new FlatIntelliJLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            System.out.println(ex);
        }
        setLayout(null);
        setLocationRelativeTo(null);
        comp();
        setVisible(true);

    }

    private JButton crearBotonConEstilo(String texto) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Lucida Sans", Font.BOLD, 20));
        boton.setBackground(new Color(24, 175, 90)); // Color verte metálico de fondo 
        boton.setForeground(new Color(255, 255, 255)); // Color de texto blanco

        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(new Color(236, 236, 255)); // Color opaco fondo cuando el cursor está sobre el botón
                boton.setForeground(new Color(251, 142, 37)); // Color de texto naranja
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(new Color(24, 175, 90)); // Restaurar verde metálico
                boton.setForeground(new Color(255, 255, 255)); // Restaurar de texto blanco
            }
        });
        return boton;
    }

    public void comp() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                int width = getWidth();
                int height = getHeight();
                Color color2 = new Color(255, 255, 255); // Blanco
                Color color1 = new Color(144, 238, 144); // Verde claro 
                GradientPaint gp = new GradientPaint(0, 0, color1, width, height, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, width, height);
            }
        };
        setContentPane(panel);
        panel.setLayout(null);

        tit = new JLabel("Modificación - " + nombre);
        tit.setBounds(150, 10, 150, 30);
        add(tit);

        txt_nom = new JLabel("Nombre: ");
        txt_nom.setBounds(10, 60, 100, 30);
        add(txt_nom);

        f_nom = new JTextField(nombre);
        f_nom.setBounds(80, 60, 100, 30);
        add(f_nom);

        txt_descri = new JLabel("Descripción: ");
        txt_descri.setBounds(10, 100, 100, 30);
        add(txt_descri);

        f_descri = new JTextField(descri);
        f_descri.setBounds(120, 100, 100, 30);
        add(f_descri);

        txt_codigo = new JLabel("Código:");
        txt_codigo.setBounds(10, 140, 100, 30);
        add(txt_codigo);

        f_codigo = new JTextField(codigo);
        f_codigo.setEditable(false);
        f_codigo.setBounds(100, 140, 100, 30);
        add(f_codigo);

        txt_eti = new JLabel("Etiqueta:");
        txt_eti.setBounds(10, 180, 100, 30);
        add(txt_eti);

        f_eti = new JTextField(eti);
        f_eti.setBounds(100, 180, 100, 30);
        add(f_eti);

        txt_dis = new JLabel("DISPONIBLE:");
        txt_dis.setBounds(10, 220, 100, 30);
        add(txt_dis);

        f_dis = new JTextField();
        f_dis.setText(dis + "");
        f_dis.setBounds(100, 220, 100, 30);
        add(f_dis);

        txt_vend = new JLabel("Vendidos:");
        txt_vend.setBounds(10, 260, 100, 30);
        add(txt_vend);

        f_vend = new JTextField();
        f_vend.setText("" + vend);
        f_vend.setBounds(100, 260, 100, 30);
        add(f_vend);

        txt_can = new JLabel("Cantidad:");
        txt_can.setBounds(10, 300, 100, 30);
        add(txt_can);

        f_can = new JTextField(can);
        f_can.setBounds(100, 300, 100, 30);
        add(f_can);

        txt_pre = new JLabel("Precio:");
        txt_pre.setBounds(10, 340, 100, 30);
        add(txt_pre);

        f_pre = new JTextField(precio + "");
        f_pre.setBounds(100, 340, 100, 30);
        add(f_pre);

        txt_m = new JLabel("Foto:");
        txt_m.setBounds(10, 380, 100, 30);
        add(txt_m);

        f_m = new JLabel();
        f_m.setBounds(100, 380, 100, 100);
        ImageIcon originalIcon = new ImageIcon(m);
        int lblwidth = f_m.getWidth();
        int lblheight = f_m.getHeight();
        Image scalImage = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        f_m.setIcon(new ImageIcon(scalImage));
        add(f_m);

        explorar = new JButton("Explorar");
        explorar.setBounds(210, 460, 150, 30);
        explorar.addActionListener(this);
        explorar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Cambiar estilo cuando el cursor está sobre el botón
                explorar.setBackground(new Color(236, 236, 255)); // Cambiar color de fondo opaco cuando el cursor está sobre el botón
                explorar.setForeground(new Color(251, 142, 37)); // Cambiar color de texto a naranja oscuro cuando el cursor está sobre el botón
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // Cambiar estilo cuando el cursor no está sobre el botón
                explorar.setBackground(new Color(135, 206, 230)); //  restaurar color de verde metalico
                explorar.setForeground(new Color(255, 255, 255)); // restaurar color de texto a blanco
            }
        });
        explorar.setBackground(new Color(135, 206, 230)); //  color de fondo a verde metalico
        explorar.setForeground(new Color(255, 255, 255)); //  color de texto a blanco
        add(explorar);

        ruta = new JLabel("");
        ruta.setBounds(100, 450, 100, 30);
        add(ruta);

         boton_aceptar = crearBotonConEstilo("Aceptar");
        boton_aceptar.setBounds(15, 550, 150, 50);
        boton_aceptar.addActionListener(this);
        panel.add(boton_aceptar);

        boton_cancelar = crearBotonConEstilo("Cancelar");
        boton_cancelar.setBounds(210, 550, 150, 50);
        boton_cancelar.addActionListener(this);
        panel.add(boton_cancelar);    
    }

//    public void cambioImg() {
//
//    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton_aceptar) {
            try {
                a_productos enviar = new a_productos();
                int can = Integer.parseInt(this.f_can.getText());
                int codigo = Integer.parseInt(this.f_codigo.getText());
                int pr = Integer.parseInt(this.f_pre.getText());
                if (f_nom.getText().equals("") || f_descri.getText().equals("") || f_eti.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "COMPLETA LOS DATOS");
                } else {
                    if (cambioImg) {
                        enviar.modificar(f_nom.getText(), f_descri.getText(), f_eti.getText(), can, selectFile, codigo, pr);
                        obj.actualizarModi();
                        setVisible(false);

                    } else {
                        System.out.println(pr);
                        enviar.modificar(f_nom.getText(), f_descri.getText(), f_eti.getText(), can, codigo, pr);
                        obj.actualizarModi();
                        setVisible(false);
                    }

                }

            } catch (Exception r) {
                JOptionPane.showMessageDialog(null, "ERROR EN LOS DATOS");
            }

        }

        if (e.getSource() == boton_cancelar) {
            setVisible(false);
        }

        if (e.getSource() == explorar) {
            JFileChooser fileChooser = new JFileChooser();

            int result = fileChooser.showOpenDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                selectFile = fileChooser.getSelectedFile();
                ruta.setText(selectFile.getName());
                try {
                    Image imag = ImageIO.read(selectFile);
                    ImageIcon originalIcon = new ImageIcon(imag);

                    int lblwidth = f_m.getWidth();
                    int lblheight = f_m.getHeight();

                    Image scalImage = originalIcon.getImage().getScaledInstance(lblwidth, lblheight, Image.SCALE_SMOOTH);
                    f_m.setIcon(new ImageIcon(scalImage));
                    cambioImg = true;

                } catch (Exception s) {
                    JOptionPane.showMessageDialog(null, "ERROR AL CARGAR");
                }
            }
        }
    }

}
